from django.apps import AppConfig


class PizzasConfig(AppConfig):
    name = 'pizzas'
