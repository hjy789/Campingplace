/* blog/static/blog/blog.js */
console.log("blog/static/blog/blog.js 파일을 로드했습니다.");